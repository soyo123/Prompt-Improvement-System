import streamlit as st
from PIL import Image
import json
import time

with open("./files/demo.json", "r") as f:
    demo_data = json.load(f)


def basic_spinner(text, t):
    """Creates spinner to simulate model waiting time.

    Args:
        text: string, text to be displayed next to the spinner.
        t: int, time in seconds for spinner to run.

    Returns:
        -
    """
    with st.spinner(text):
        time.sleep(t)


def generate_hints(disabled=False):
    """Generates hints after passing initial prompt. Creates button for suggestions generation.

    Returns:
        -
    """
    explain_process(disabled=True)
    with st.chat_message("assistant"):
        if not st.session_state.suggestions_generated_00:
            basic_spinner("Generating hints...", 3)
            st.toast('Hints for your initial prompt has been generated.')
            st.write(demo_data['explanation']["revise_hints"])
        else:
            st.markdown(demo_data['explanation']["revise_hints_colored"])

    with st.chat_message("user"):
        if not st.session_state.suggestions_generated_00:
            basic_spinner('Waiting for User...', 3)
        st.write(demo_data['explanation']["hint_00_gen_suggestions"])

    st.button('Generate suggestions for first hint', on_click=generate_suggestions_00, disabled=disabled)


def generate_suggestions_00(disabled=False):
    """Generates suggestions for first hint after button click. Creates button for hint revision.
    Does not handle other hints (only hint 0 for explanation purposes).

    Returns:
        -
    """
    st.session_state.suggestions_generated_00 = True
    generate_hints(disabled=True)
    with st.chat_message("assistant"):
        if not st.session_state['hint_revised']:
            basic_spinner('Generating suggestions for hint customization...', 3)
            st.toast('Suggestions how to customize hint no 1 has been generated.')
            st.markdown(demo_data['explanation']['hint_00_suggestions'])
        else:
            st.markdown(demo_data['explanation']['hint_00_suggestions_colored'])

    st.session_state.status = "suggestions_generated_00"
    with st.chat_message("user"):
        if not st.session_state['hint_revised']:
            basic_spinner('Waiting for User...', 3)
        st.write(demo_data['explanation']["hint_00_revise_hint"])

    st.button('Revise first hint', on_click=revise_hint, disabled=disabled)


def revise_hint(disabled=False):
    """Revises hint on button click after suggestion generation. Creates button for initial prompt revision.

    Returns:
        -
    """
    st.session_state.hint_revised = True
    if st.session_state.status == "suggestions_generated_00":
        generate_suggestions_00(disabled=True)
        if not st.session_state.prompt_revised:
            basic_spinner('Revising first hint according to chosen option...', 3)
            st.toast('First hint has been revised.')
        with st.chat_message("assistant"):
            st.write("**Revised first hint:**")
            st.write(demo_data["hint_00"]["revised"])
    st.write("**Similarly, all hints are revised according to User's chosen options.**")

    with st.chat_message("user"):
        if not st.session_state.prompt_revised:
            basic_spinner('Waiting for User...', 3)
        st.write(demo_data['explanation']['revise_prompt'])

    st.button('Revise initial prompt', on_click=revise_prompt, disabled=disabled)


def revise_prompt(disabled=False):
    """Revises prompt on button click. Creates button for final answer generation.

    Returns:

    """
    st.session_state.prompt_revised = True
    revise_hint(disabled=True)
    with st.chat_message("assistant"):
        if not st.session_state.answer_generated:
            basic_spinner('Revising initial prompt to make it more accurate...', 3)
            st.toast('Your initial prompt has been revised.')
        st.write("**Revised prompt:**")
        st.write(demo_data['revised_prompt'][2:])

    st.button('Generate Answer', on_click=generate_answer, disabled=disabled)


def generate_answer():
    """Generates final answer. This is the last stage of explanation site.

    Returns:
        -
    """
    st.session_state.answer_generated = True
    revise_prompt(disabled=True)
    with st.chat_message("assistant"):
        basic_spinner('Generating answer...', 3)
        st.toast('Your answer to the revised prompt has been generated.')
        st.write('**Answer:**')
        for t in [0, 1, 2]:
            st.write(demo_data['output']['text'][t])
            try:
                st.code(demo_data['output']['code'][t], language='python')
            except IndexError:
                continue
    st.write('---')


def explain_process(disabled=False):
    """Main function of explanation process - it has to be run inside main script while selected.
    Initializes explanation process.

    Returns:
        -
    """
    st.title(":books: Prompt Generation Process Explained")
    st.divider()
    st.write(demo_data['explanation']['intro'])
    demo_flow_image = Image.open('./files/demo_flow.png')
    st.image(demo_flow_image, caption='Demo Flow Explained Step-by-Step')
    st.divider()

    # Initialize status history
    if "messages" not in st.session_state:
        st.session_state.messages = []
    if "suggestions_generated_00" not in st.session_state:
        st.session_state.suggestions_generated_00 = False
    if "hint_revised" not in st.session_state:
        st.session_state.hint_revised = False
    if "prompt_revised" not in st.session_state:
        st.session_state.prompt_revised = False
    if "answer_generated" not in st.session_state:
        st.session_state.answer_generated = False

    # Display chat messages from history on app rerun
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    st.chat_message("user").markdown(demo_data['explanation']['initial_prompt'])
    st.session_state.status = "init"

    st.button('Generate hints', on_click=generate_hints, key='hint_generator', disabled=disabled)
