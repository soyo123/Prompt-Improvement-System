import streamlit as st
import openai
import warnings
import re
import json

with open("./files/demo.json", "r") as f:
    demo_data = json.load(f)

with open("./files/config.json", "r") as f:
    config = json.load(f)


openai.api_type = config['api_config']['api_type']
openai.api_version = config['api_config']['api_version']
openai.api_base = config['api_config']['api_base']
openai.api_key = config['api_config']['api_key']
#openai.api_type = "azure"
#openai.api_version = "2023-05-15"
#openai.api_base = "https://pl-dev-eu-openai.openai.azure.com/"
#openai.api_key = "17977f4b1f244eb7bb1d6452b2acb2e6"



class MultiselectSuggestion:
    """Class to create repetitive, expanding elements with hint revision according to selected suggestions.
    Prints initial state (hint, multi-selection element) after initialization.

    Attributes:
        _expander: st.expander, multi-element container with initial hint content, multi-select element, button for
            hint revision and revised text content.
        _options: list, list of four suggestions for hint customization.
        _key: string, unique hint key, e.g., "handle_hint_0" for first hint.
        _hint_id: int, hint id.
        _previous_expanders: list[st.expander], list of all previous expanders, e.g., for hint_id == 2 previous
            expanders are 0 and 1. Used to perceive all hints printed.
        _multiselect_suggestions: st.multiselect, box for suggestion multi-selection.
    """
    def __init__(self, hint_id, previous_expanders):
        self._expander = st.expander(st.session_state["generated_hint_"+str(hint_id)], expanded=True)
        self._options = st.session_state["generated_suggestions_"+str(hint_id)]
        self._key = "handle_hint_"+str(hint_id)
        self._hint_id = hint_id
        self._previous_expanders = previous_expanders
        self._multiselect_suggestions = self._expander.multiselect(
            label='Choose the option(s)',
            options=self._options,
            on_change=self.multiselect_suggestion_on_change,
            key=self._key,
            max_selections=4,
        )

    def get_expander(self):
        """Getter for MultiselectSuggestion expander attribute."""
        return self._expander

    def multiselect_suggestion_on_change(self, disabled=False):
        """Prints button for hint revision generation. Keeps previous hints multi-selection actions printed."""
        hint_0, hint_1, hint_2 = gen_hints_on_click()
        for i, previous_expander in enumerate(self._previous_expanders):
            st.session_state["handle_hint_"+str(i)+"_revision"] = True
            previous_expander.button(
                label='Revise hint with selected options',
                key='hold_hint_revision_button_'+str(i),
                disabled=True
            )
            previous_expander.write(st.session_state['generated_revised_hint_'+str(i)])
        if len(st.session_state[self._key]) > 0:
            if self._hint_id == 0:
                self._expander = hint_0.get_expander()
            self._expander.button(
                label='Revise hint with selected options',
                key=self._key + "_revision",
                on_click=self.generate_hint_revision,
                disabled=disabled
            )
            st.session_state[f"hint_{self._hint_id}_constructor"] = True

    def generate_hint_revision(self):
        """Prints revised hint inside expanding container."""
        self.multiselect_suggestion_on_change(disabled=True)
        if st.session_state[self._key + "_revision"]:
            with self._expander:
                with st.spinner('Revising hint...'):
                    hint_suggestion = ' '.join([
                        suggestion for suggestion in st.session_state['handle_hint_'+str(self._hint_id)]]
                    )
                    input_content = {
                        "initial_prompt": st.session_state.input_initial_prompt,
                        "generated_hint": st.session_state['generated_hint_'+str(self._hint_id)],
                        "generated_suggestion": hint_suggestion,
                        "revised_hints": ""
                    }
                    if input_content["generated_suggestion"] == 'Do not specify (do not change initial hint).':
                        gen_hint_revision = input_content["generated_hint"]
                    else:
                        gen_hint_revision = send_to_openai('hint_revision', input_content)

                    if 'generated_revised_hint_'+str(self._hint_id) not in st.session_state:
                        st.session_state['generated_revised_hint_'+str(self._hint_id)] \
                            = gen_hint_revision
        self._expander.write(st.session_state['generated_revised_hint_'+str(self._hint_id)])
        st.session_state["hint_revision_" + str(self._hint_id)] = True


def generate_answer():
    """Generates final answer as a result of revised prompt served to LLM.

    Returns:
        -
    """
    revise_prompt(disabled=True)
    with st.spinner('Generating answer...'):
        response = openai.Completion.create(
            engine=config['template_config']['prompt_revision']['engine'],
            prompt=st.session_state.revised_prompt,
            temperature=config['template_config']['prompt_revision']['temperature'],
            max_tokens=config['template_config']['prompt_revision']['max_tokens']
        )
        response = response['choices'][0]['text']
        if 'answer' not in st.session_state:
            st.session_state.answer = response
    st.success('Done!')
    st.subheader('Answer:')
    st.write(st.session_state['answer'])
    st.write('---')
    st.button("Clear session and try it again!",
              on_click=clear_session,
              key='clear_session',
              disabled=False
              )


def clear_session():
    """Delete all the items in Session state."""
    if st.session_state['clear_session']:
        for key in st.session_state.keys():
            del st.session_state[key]
        st.session_state.feature_selected = ':pencil: Try it'
        run_try_it(disabled=False)


def revise_prompt(disabled=False):
    """Revises initial prompt according to redesigned hints. Keeps all history printed on side. Works on button click.
    Defines button to generate the final answer.

    Args:
        disabled: disables final answer generation button after click.

    Returns:
        -
    """
    hint_0, hint_1, hint_2 = gen_hints_on_click(disabled=True)
    if not disabled:
        with st.spinner('Revising initial prompt...'):
            revised_hints = [st.session_state['generated_revised_hint_0'],
                             st.session_state['generated_revised_hint_1'],
                             st.session_state['generated_revised_hint_2']]
            generated_hints = ' '.join(hint for hint in revised_hints)
            input_content = {
                "initial_prompt": st.session_state.input_initial_prompt,
                "generated_hint": "",
                "generated_suggestion": "",
                "revised_hints": generated_hints
            }
            gen_revision = send_to_openai('prompt_revision', input_content)
            if 'revised_prompt' not in st.session_state:
                st.session_state.revised_prompt = gen_revision
    st.success('Done!')
    st.divider()
    st.subheader('Your new prompt is:')
    st.write(st.session_state['revised_prompt'])
    st.divider()
    for hint_id, hint in enumerate([hint_0, hint_1, hint_2]):
        hint.get_expander().write(st.session_state['generated_revised_hint_'+str(hint_id)])
    st.button("Use prompt",
              on_click=generate_answer,
              key='generate_answer',
              disabled=disabled
              )


def get_template(step_type: str, input_content: dict) -> str:
    """Returns appropriate template form config file, depending on step_type.

    Args:
        step_type: string, specifies what type of generation is performed.
        input_content: dict, texts used to replace keys in the template.

    Returns:
        template: string, template with filled information.
    """
    template = config["template_config"][step_type]['template']
    if step_type == "hint_generation":
        return template \
            .replace("[INITIAL PROMPT]", input_content['initial_prompt'])
    elif step_type == "suggestion_generation":
        return template \
            .replace("[INITIAL PROMPT]", input_content['initial_prompt']) \
            .replace("[GENERATED HINT]", input_content['generated_hint'])
    elif step_type == "hint_revision":
        return template \
            .replace("[GENERATED SUGGESTION]", input_content['generated_suggestion']) \
            .replace("[GENERATED HINT]", input_content['generated_hint'])
    elif step_type == "prompt_revision":
        return template \
            .replace("[INITIAL PROMPT]", input_content['initial_prompt']) \
            .replace("[REVISED HINTS]", input_content['revised_hints'])


def process_output(output: str) -> list:
    """Splitting the text using regex to remove numbers - used for generated hints and suggestions.

    Args:
        output: string, raw text generated by LLM.

    Returns:
        separated_hints: list[string], list of hints or suggestions extracted from text.
    """
    pattern = re.split(r'\d+\.\s+', output)
    separated_hints = [part.replace("\\n", "") for part in pattern if part.strip()]
    # TODO: Add exception to replace all hints as one and two empty if format is different than expected.
    return separated_hints


def send_to_openai(step_type: str, input_content: dict, depth: int = 0) -> str:
    """Sends input text with relevant template.

    Args:
        step_type: string, may be one of: "hint_generation", "suggestion generation", "hint revision" and
            "prompt revision", specifies what template should be used.
        input_content: dictionary, contains elements such as hints, suggestions etc. that are used to replace
            special keys in templates.
        depth: int, current recursion stack level, used to stop rerunning function when predefined limit
            (self._recursion_limit) has been reached.

    Returns:
        response: string, model response to provided prompt, generated text accordingly to the step.
    """
    recursion_limit = 3
    prompt = get_template(step_type, input_content)
    response = openai.Completion.create(
        engine=config["template_config"][step_type]['engine'],
        prompt=prompt,
        temperature=config["template_config"][step_type]['temperature'],
        max_tokens=config["template_config"][step_type]['max_tokens']
    )
    response = response['choices'][0]['text']

    # Two conditions to handle empty input and wrong hint/suggestion format. Reruns function.
    output_format = re.compile('1.*2.*3.*')
    if step_type in ["hint_generation", "suggestion_generation"] and output_format.match(response) is None:
        if depth < recursion_limit:
            st.toast(f"Failed to generate {step_type} correctly. Wrong format. Rerunning generation. Please wait.")
            warnings.warn(f"Failed to generate {step_type} correctly. Wrong format. Rerunning function.")
            response = send_to_openai(step_type, input_content, depth + 1)
    if len(response) == 0:
        if depth < recursion_limit:
            st.toast(f"Failed to generate {step_type} correctly. Empty string. Rerunning generation. Please wait.")
            warnings.warn(f"Failed to generate {step_type} correctly. Empty string. Rerunning function.")
            response = send_to_openai(step_type, input_content, depth + 1)
    return response


def get_models_completion():
    input_content = {
        "initial_prompt": st.session_state.input_initial_prompt,
        "generated_hint": "",
        "generated_suggestion": "",
        "revised_hints": ""
    }
    # Generate hints.
    gen_hints = send_to_openai('hint_generation', input_content)
    listed_hints = process_output(gen_hints)
    if 'generated_hint_0' not in st.session_state:
        st.session_state.generated_hint_0 = listed_hints[0]
    if 'generated_hint_1' not in st.session_state:
        st.session_state.generated_hint_1 = listed_hints[1]
    if 'generated_hint_2' not in st.session_state:
        st.session_state.generated_hint_2 = listed_hints[2]
    # Generate suggestions.
    for hint_id, hint_value in enumerate(listed_hints):
        input_content.update({'generated_hint': hint_value})
        gen_hint_suggestions = send_to_openai('suggestion_generation', input_content)
        listed_hint_suggestions = process_output(gen_hint_suggestions)
        listed_hint_suggestions.append('Do not specify (do not change initial hint).')
        if 'generated_suggestions_' + str(hint_id) not in st.session_state:
            st.session_state['generated_suggestions_' + str(hint_id)] = listed_hint_suggestions


def gen_hints_on_click(disabled: bool = False):
    """Generates hints on button click in expanding containers.

    Args:
        disabled: boolean, turns off possibility to click initial prompt revision button, when it was used.

    Returns:
        hint_0: MultiselectSuggestion class object for hint no 0.
        hint_1: MultiselectSuggestion class object for hint no 1.
        hint_2: MultiselectSuggestion class object for hint no 2.
    """
    run_try_it(disabled=True)
    if st.session_state["FormSubmitter:input_form-Generate hints"]:
        with st.spinner('Generating hints...'):
            get_models_completion()
        st.success('Done!')

    if 'hint_revision_0' not in st.session_state:
        st.session_state.hint_revision_0 = False
    if 'hint_revision_1' not in st.session_state:
        st.session_state.hint_revision_1 = False
    if 'hint_revision_2' not in st.session_state:
        st.session_state.hint_revision_2 = False
    if 'hint_0_constructor' not in st.session_state:
        st.session_state.hint_0_constructor = False
    if 'hint_1_constructor' not in st.session_state:
        st.session_state.hint_1_constructor = False
    if 'handle_hint_2_revision' not in st.session_state:
        st.session_state.handle_hint_2_revision = False

    hint_0 = MultiselectSuggestion(hint_id=0, previous_expanders=[])
    hint_1 = MultiselectSuggestion(hint_id=1, previous_expanders=[hint_0.get_expander()])
    hint_2 = MultiselectSuggestion(hint_id=2, previous_expanders=[hint_0.get_expander(), hint_1.get_expander()])

    if st.session_state['handle_hint_2_revision']:
        st.button(
            "Revise initial prompt",
            on_click=revise_prompt,
            key='revise_prompt',
            disabled=disabled
        )

    return hint_0, hint_1, hint_2


def run_try_it(disabled=False):
    """Main function to run after selecting "Demo" option in sidebar. Gets initial prompt from a User
    and creates button (hint generation) to initiate further steps.

    Returns:
        -
    """
    st.title(":pencil: Try it")
    st.divider()

    with st.form(key='input_form'):
        st.text_input(
            label='Type initial prompt:',
            key="input_initial_prompt",
            placeholder='No prompt has been written. Provide your initial prompt.',
            disabled=disabled
        )

        st.form_submit_button(
            "Generate hints",
            args=st.session_state['input_initial_prompt'],
            on_click=gen_hints_on_click,
            disabled=disabled
        )
