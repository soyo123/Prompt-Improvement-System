"""Configuration file for all generation steps."""

config = {
    "hint_generation": {
        "template": "Give me 3 hints how to improve this prompt: "
                    "[INITIAL PROMPT] Return the output in following format: 1. \n2. \n3.",
        "engine": "text-davinci-001",
        "temperature": 1.0,
        "max_tokens": 256,
        "no_hints": 3
    },
    "suggestion_generation": {
        "template": "You have a prompt [INITIAL PROMPT] Provide a list of three options for a hint: [GENERATED HINT] "
                    "The options should have no more than 3-6 words. "
                    "Return the output in following format: 1. \n2. \n3. Return exactly three options.",
        "engine": "text-davinci-001",
        "temperature": 1.0,
        "max_tokens": 256,
        "no_suggestions": 3
    },
    "hint_revision": {
        "template": "Revise a suggestion: [GENERATED HINT] Use following information: [GENERATED SUGGESTION]",
        "engine": "text-davinci-001",
        "temperature": 1.0,
        "max_tokens": 256
    },
    "prompt_revision": {
        "template": "I want to improve my prompt: [INITIAL PROMPT] including following information: [REVISED HINTS]. "
                    "Propose me a better version of my prompt that original.",
        "engine": "text-davinci-001",
        "temperature": 1.0,
        "max_tokens": 256
    }
}