"""Script to run evaluation pipeline on previously prepared dataset and pre-generated revised hints."""

import argparse
import utils


def generate(data_filepath: str):
    """Generate data: hints, suggestions and final prompt revisions."""
    generator = utils.DataGenerator(test_data_filepath=data_filepath)
    generator.generate_data()


def evaluate(data_filepath: str):
    """Evaluate method on test dataset."""
    evaluator = utils.CountVectorizerEvaluator(test_data_filepath=data_filepath)
    evaluator_bert = utils.BertEvaluator(test_data_filepath=data_filepath)
    evaluator.evaluate()
    evaluator_bert.evaluate()
    evaluator.save_results()


def run_pipeline(data_filepath: str):
    """Run full pipeline: data generation and evaluation."""
    generate(data_filepath)
    evaluate(data_filepath)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-fp", "--filepath", help="Filepath to raw dataset.")
    parser.add_argument("-a", "--action", help="Action to be taken, may be: generate, evaluate, full_pipeline.")

    # test_data_filepath = "../data/test_5_prompts.json"
    args = parser.parse_args()
    if args.action == 'generate':
        generate(data_filepath=args.filepath)
    elif args.action == 'evaluate':
        evaluate(data_filepath=args.filepath)
    elif args.action == 'full_pipeline':
        run_pipeline(data_filepath=args.filepath)
