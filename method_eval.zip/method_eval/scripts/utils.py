"""Definitions of evaluator classes."""

import json
import re
import warnings
import openai
import evaluate
import numpy as np
from os import path
from tqdm import tqdm
from datetime import datetime
from itertools import product
from abc import ABC, abstractmethod
from openai import embeddings_utils
from sklearn.metrics import pairwise
from sklearn.feature_extraction.text import CountVectorizer
from nltk.stem import PorterStemmer
from nltk.translate import bleu_score
from transformers import AutoTokenizer

from config import config


class Evaluator(ABC):
    """Abstract class for different evaluators.

    Args:
        _method: string, unique name for child classes, can be "count_vectorizer", "openai" or "bert".
        _test_data_filename: string, path to test dat JSON file.
        _test_data: dict, automatically loaded data from specified filepath.
        _initial_prompt_ids: list of strings, initial prompt ids from loaded dataset.
        _revision_ids: list of strings, revision ids from loaded file (all 512 combinations).
        _stemmer: stemming objects for preprocessing.
    """
    def __init__(self, method: str, test_data_filepath: str = "../data/test.json"):
        self._method = method
        self._test_data_filename = test_data_filepath
        self._test_data = self._load_test_data()
        self._initial_prompt_ids = list(self._test_data['outputs'].keys())
        self._revision_ids = list(self._test_data['outputs'][self._initial_prompt_ids[0]]['revisions'].keys())
        self._stemmer = PorterStemmer()

    def _load_test_data(self) -> dict:
        """Loads test dataset from provided JSON filename."""
        if path.isfile(self._test_data_filename):
            with open(self._test_data_filename, "r") as f:
                test_data = json.load(f)
                return test_data
        else:
            raise FileNotFoundError("Test dataset does not exist, please check provided filepath.")

    @abstractmethod
    def _cosine_similarity(self, output: np.array, target: np.array) -> float:
        """Computes cosine similarity between two embedded texts."""
        pass

    @staticmethod
    def _bleu(output: str, target: str) -> dict:
        """Computes BLEU score between two string texts.
        BLEU is used mostly for machine translation, so it might be irrelevant in case of creative text generation.

        Args:
            output: string, hypothesis for BLEU Score, preprocessed.
            target: string, reference for BLEU Score, preprocessed.

        Returns:
            result: dict,
        """
        chencherry = bleu_score.SmoothingFunction()
        result = {
            "bleu_sentence":
                bleu_score.sentence_bleu(
                    [target.split()], output.split(),
                    weights=(0.5, 0.5),
                    smoothing_function=chencherry.method1
                ),
            "bleu_modified_precision":
                float(bleu_score.modified_precision([target.split()], output.split(), n=1))
        }
        return result

    @staticmethod
    def _rouge(output: str, target: str) -> dict:
        """Computes ROUGE scores between two string texts.
        ROUGE measures syntactical matches not semantics, so it does not include synonyms.
        ROUGE is used mostly for summarization and machine translation, so it might be irrelevant in case of creative
        text generation.

        Args:
            output: string, hypothesis for ROUGE Scores, preprocessed.
            target: string, reference for ROUGE Scores, preprocessed.

        Returns:
            results: dict, consists of 4 ROUGE metrics, keys: 'rouge1', 'rouge2', 'rougeL', 'rougeLsum'.
        """
        rouge = evaluate.load('rouge')
        no_references = len(output.split())
        if no_references != 0:
            results = rouge.compute(
                predictions=output.split(), references=[target.split()]*no_references, rouge_types=['rouge1']
            )
        else:
            results = {'rouge1': 0.0}
        return results

    def _stem(self, sentence: str) -> str:
        """Word stemming."""
        return ' '.join([self._stemmer.stem(x) for x in sentence.split()])

    def _preprocess_text(self, sentence: str) -> str:
        """Text preprocessing method:
            - removes punctuation marks,
            - removes new line symbol,
            - stems each word.
        """
        preprocessed_sentence = self._stem(re.sub(r'[^\w\s]', ' ', sentence).replace("\n", " "))
        return preprocessed_sentence

    def _get_saving_path(self) -> str:
        """Constructs saving path from test data filename and method name."""
        file_basename = path.basename(self._test_data_filename).split(".")[0]
        saving_path = f"./results/{file_basename}_results.json"
        return saving_path

    @abstractmethod
    def evaluate(self):
        """Runs evaluation pipeline."""
        pass

    def save_results(self):
        """Saves test data int test.json file."""
        file_basename = path.basename(self._test_data_filename).split(".")[0]
        saving_path = f"./results/{file_basename}.json"
        with open(saving_path, 'w', encoding='utf-8') as f:
            json.dump(self._test_data, f, indent=2)
        self._get_best_revision()

    def _get_best_revision(self):
        """Finds best results, based on chosen method, from all 512 revised prompts per initial prompt.
        Saves these results in external file.
        # TODO: Save best options for each metric with information about other results.
        """
        results = dict()
        metrics = ["cosine_similarity_count_vectorizer", "cosine_similarity_bert", "bleu_sentence",
                   "bleu_modified_precision", "rouge1"] 
        for prompt_id in self._initial_prompt_ids:
            results[prompt_id] = dict()
            results[prompt_id]['initial_prompt'] = self._test_data['outputs'][prompt_id]["initial_prompt"]
            for metric in metrics:
                try:
                    results[prompt_id].update({metric: self._test_data['test'][prompt_id][metric]})
                except KeyError:
                    pass
            results[prompt_id]['best_results'] = dict()
            # Simplify levels.
            best_results = results[prompt_id]['best_results']
            revisions = self._test_data['outputs'][prompt_id]['revisions']
            hints = self._test_data['outputs'][prompt_id]["hints"]
            # Iterate over all available metrics.
            for metric in metrics:
                try:
                    best_results[metric] = dict()
                    prompt_result = dict()
                    # Search for best metric value, find its id.
                    for revision_id in self._revision_ids:
                        revised_prompt_metric = revisions[revision_id][metric]
                        prompt_result.update({revision_id: revised_prompt_metric})
                    best_revision_id = max(prompt_result, key=prompt_result.get)
                    best_metric = max(prompt_result.values())
                    hint_ids = best_revision_id.split("-")
                    best_results[metric].update({"revision_id": best_revision_id})
                    best_results[metric].update({
                        "revised_prompt": revisions[max(prompt_result, key=prompt_result.get)]['value']})
                    best_results[metric].update({
                        "revised_hints": [
                            hints["0"]["suggestions"][hint_ids[0]]["revision"],
                            hints["1"]["suggestions"][hint_ids[1]]["revision"],
                            hints["2"]["suggestions"][hint_ids[2]]["revision"]],
                        "suggestions": [
                            hints["0"]["suggestions"][hint_ids[0]]["value"],
                            hints["1"]["suggestions"][hint_ids[1]]["value"],
                            hints["2"]["suggestions"][hint_ids[2]]["value"]]})
                    best_results[metric].update({metric: best_metric})
                    for other_metric in metrics:
                        if other_metric != metric:
                            try:
                                best_results[metric].update({other_metric: revisions[best_revision_id][other_metric]})
                            except KeyError:
                                pass
                except KeyError:
                    pass

        with open(self._get_saving_path(), 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2)
        print(f"Best result saved into {self._get_saving_path()}.")


class CountVectorizerEvaluator(Evaluator):
    """Evaluator based on Count Vectorizer.
    Args:
        _method: string, unique name equal to "count_vectorizer".
        _test_data_filename: string, path to test dat JSON file.
        _test_data: dict, automatically loaded data from specified filepath.
        _initial_prompt_ids: list of strings, initial prompt ids from loaded dataset.
        _revision_ids: list of strings, revision ids from loaded file (all 512 combinations).
        _stemmer: stemming objects for preprocessing.
    """
    def __init__(self, test_data_filepath: str = "../data/test.json"):
        super().__init__(method="count_vectorizer", test_data_filepath=test_data_filepath)

    def _cosine_similarity(self, output: np.array, target: np.array) -> float:
        """Computes cosine similarity between two embedded texts.

        Args:
            output: matrix of shape (n_samples_X, n_features), output from model it might be the revised prompt
                or the final answer.
            target: matrix of shape (n_samples_X, n_features), target text, concatenated expectations specified
                in test dataset.

        Returns:
            result: a cosine similarity value between the output and the target.
        """
        result = pairwise.cosine_similarity(output, target)
        return result[0][0]

    def evaluate(self):
        for prompt_id in tqdm(self._initial_prompt_ids, desc="Evaluating with Count Vectorizer"):
            expectations = self._test_data['test'][prompt_id]['expectations']
            revisions = self._test_data['outputs'][prompt_id]['revisions']
            target = " . ".join(expectations)
            target_preprocessed = self._preprocess_text(target)
            initial_prompt = self._test_data['test'][prompt_id]['initial_prompt']
            initial_prompt_preprocessed = self._preprocess_text(initial_prompt)

            # Create separate vectorizer for every initial prompt, to fnd the most similar revision to expectations
            vectorizer = CountVectorizer(analyzer='word', ngram_range=(1, 2), lowercase=True, stop_words='english')
            corpus = [self._preprocess_text(revisions[revision_id]['value']) for revision_id in self._revision_ids]
            corpus.append(target_preprocessed)
            corpus.append(initial_prompt_preprocessed)
            vectorizer.fit_transform(corpus)

            # Calculate metrics for initial prompt.
            target_vectorized = vectorizer.transform([target_preprocessed])
            initial_prompt_vectorized = vectorizer.transform([initial_prompt_preprocessed])
            self._test_data['test'][prompt_id][f'cosine_similarity_{self._method}'] = self._cosine_similarity(
                initial_prompt_vectorized, target_vectorized)
            self._test_data['test'][prompt_id].update(self._bleu(initial_prompt_preprocessed, target_preprocessed))
            self._test_data['test'][prompt_id].update(self._rouge(initial_prompt_preprocessed, target_preprocessed))

            for revision_id in self._revision_ids:
                revised_prompt = revisions[revision_id]['value'].replace("\n", " ")
                revised_prompt_preprocessed = self._preprocess_text(revised_prompt)
                revised_prompt_vectorized = vectorizer.transform([revised_prompt_preprocessed])
                revisions[revision_id][f'cosine_similarity_{self._method}'] = \
                    self._cosine_similarity(revised_prompt_vectorized, target_vectorized)
                revisions[revision_id].update(self._bleu(revised_prompt_preprocessed, target_preprocessed))
                revisions[revision_id].update(self._rouge(revised_prompt_preprocessed, target_preprocessed))


class OpenAIEvaluator(Evaluator):
    """Evaluator based on OpenAI.
        Args:
            _method: string, unique name equal to "openai".
            _test_data_filename: string, path to test dat JSON file.
            _test_data: dict, automatically loaded data from specified filepath.
            _initial_prompt_ids: list of strings, initial prompt ids from loaded dataset.
            _revision_ids: list of strings, revision ids from loaded file (all 512 combinations).
            _stemmer: stemming objects for preprocessing.
    """
    def __init__(self, test_data_filepath: str = "../data/test.json"):
        super().__init__(method="openai", test_data_filepath=test_data_filepath)
        self._engine = "text-embedding-ada-002"

    def _cosine_similarity(self, output: np.array, target: np.array) -> float:
        result = embeddings_utils.cosine_similarity(output, target)
        return result

    def evaluate(self):
        for prompt_id in tqdm(self._initial_prompt_ids, desc="Evaluating with OpenAI embeddings"):
            initial_prompt = self._test_data['test'][prompt_id]['initial_prompt']
            expectations = self._test_data['test'][prompt_id]['expectations']
            revisions = self._test_data['outputs'][prompt_id]['revisions']
            target = ". ".join(expectations)
            target_embedding = embeddings_utils.get_embedding(target, engine=self._engine)
            initial_prompt_embedding = embeddings_utils.get_embedding(initial_prompt, engine=self._engine)
            self._test_data['test'][prompt_id][f'cosine_similarity_{self._method}'] = \
                self._cosine_similarity(initial_prompt_embedding, target_embedding)
            for revision_id in self._revision_ids:
                revised_prompt = revisions[revision_id]['value']
                revised_prompt_embedding = embeddings_utils.get_embedding(revised_prompt, engine=self._engine)
                revisions[revision_id][f'cosine_similarity_{self._method}'] = \
                    self._cosine_similarity(revised_prompt_embedding, target_embedding)


class BertEvaluator(Evaluator):
    """Evaluator based on BERT.
        Args:
            _method: string, unique name equal to "bert".
            _test_data_filename: string, path to test dat JSON file.
            _test_data: dict, automatically loaded data from specified filepath.
            _initial_prompt_ids: list of strings, initial prompt ids from loaded dataset.
            _revision_ids: list of strings, revision ids from loaded file (all 512 combinations).
            _stemmer: stemming objects for preprocessing.
    """
    def __init__(self, test_data_filepath: str = "../data/test.json"):
        super().__init__(method="bert", test_data_filepath=test_data_filepath)
        self._tokenizer = AutoTokenizer.from_pretrained('bert-base-uncased')

    def _cosine_similarity(self, output: np.array, target: np.array) -> float:
        """Computes cosine similarity between two embedded texts.

        Args:
            output: matrix of shape (n_samples_X, n_features), output from model it might be the revised prompt
                or the final answer.
            target: matrix of shape (n_samples_X, n_features), target text, concatenated expectations specified
                in test dataset.

        Returns:
            result: a cosine similarity value between the output and the target.
        """
        result = pairwise.cosine_similarity(
            np.array([output['input_ids']]),
            np.array([target['input_ids']])
        )
        return result[0][0]

    def evaluate(self):
        for prompt_id in tqdm(self._initial_prompt_ids, desc="Evaluating with BERT encoder"):
            initial_prompt = self._test_data['test'][prompt_id]['initial_prompt']
            expectations = self._test_data['test'][prompt_id]['expectations']
            revisions = self._test_data['outputs'][prompt_id]['revisions']
            target = " . ".join(expectations)
            encoded_target = self._tokenizer(
                target, padding="max_length",
                truncation=True, max_length=256
            )
            encoded_initial_prompt = self._tokenizer(
                initial_prompt, padding="max_length",
                truncation=True, max_length=256
            )
            self._test_data['test'][prompt_id][f'cosine_similarity_{self._method}'] = \
                self._cosine_similarity(encoded_initial_prompt, encoded_target)
            for revision_id in self._revision_ids:
                revised_prompt = revisions[revision_id]['value']
                encoded_revised_prompt = self._tokenizer(
                    revised_prompt, padding="max_length",
                    truncation=True, max_length=256
                )
                revisions[revision_id][f'cosine_similarity_{self._method}'] = \
                    self._cosine_similarity(encoded_revised_prompt, encoded_target)


class DataGenerator:
    """Test data generation class.
    Should be used to generate missing test data elements such as hints, suggestions and revisions.
    Generates revised prompts for all possible combinations of hints and suggestions.
    All run-specific information should be included in config.py file.

    Args:
        _key_elements: list, list of text keys used in generation templates.
        _possible_hint_suggestions: list, list of possible suggestions, that can be applied to every hint before
            revision.
        _suggestions_combinations: list[list], helper for combinations creation.
        _combinations: list, helper list of all revised hints combinations to generate better prompts.
        _suggestions: list, list of combinations of suggestions applied to revised hints and finally prompt,
            e.g., structured like 0-0-0.
        _recursion_limit: int, total number of OpenAI generation attempts if output is different from expected
            (e.g., empty, bad format).
        _test_data_filename: string, path to test dataset.
        _test_data: string, dataset loaded from provided path to test dataset, loaded automatically.
        _saving_path: string, path to saving directory wih results filename, created automatically.
    """
    def __init__(self, test_data_filepath: str = "../data/test.json"):
        self._key_elements = ["[INITIAL PROMPT]", "[GENERATED HINT]", "[GENERATED SUGGESTION]", "[REVISED HINTS]"]
        self._possible_hint_suggestions = ['0', '1', '2', '3', '01', '02', '12', '012']
        self._suggestions_combinations = [self._possible_hint_suggestions] * 3
        self._combinations = product(*self._suggestions_combinations, repeat=1)
        self._suggestions = ['-'.join(combination) for combination in self._combinations]
        self._recursion_limit = 3
        self._test_data_filename = test_data_filepath
        self._test_data = self._load_test_data()
        self._saving_path = self._get_saving_path()

    def _load_test_data(self) -> dict:
        """Loads test dataset from self._test_data_filename.

        Returns:
            test_data: dict, full test dataset that is used in self._test_data variable.
        """
        if path.isfile(self._test_data_filename):
            with open(self._test_data_filename, "r") as f:
                test_data = json.load(f)
                return test_data
        else:
            raise FileNotFoundError("Test dataset does not exist, please check provided filepath.")

    @staticmethod
    def _get_template(step_type: str, input_content: dict) -> str:
        """Returns appropriate template form config file, depending on step_type.

        Args:
            step_type: string, specifies what type of generation is performed.
            input_content: dict, texts used to replace keys in the template.

        Returns:
            template: string, template with filled information.
        """
        template = config[step_type]['template']
        if step_type == "hint_generation":
            return template \
                .replace("[INITIAL PROMPT]", input_content['initial_prompt'])
        elif step_type == "suggestion_generation":
            return template \
                .replace("[INITIAL PROMPT]", input_content['initial_prompt']) \
                .replace("[GENERATED HINT]", input_content['generated_hint'])
        elif step_type == "hint_revision":
            return template \
                .replace("[GENERATED SUGGESTION]", input_content['generated_suggestion']) \
                .replace("[GENERATED HINT]", input_content['generated_hint'])
        elif step_type == "prompt_revision":
            return template \
                .replace("[INITIAL PROMPT]", input_content['initial_prompt']) \
                .replace("[REVISED HINTS]", input_content['revised_hints'])

    def _send_to_openai(self, step_type: str, input_content: dict, depth: int = 0) -> str:
        """Sends input text with relevant template.

        Args:
            step_type: string, may be one of: "hint_generation", "suggestion generation", "hint revision" and
                "prompt revision", specifies what template should be used.
            input_content: dictionary, contains elements such as hints, suggestions etc. that are used to replace
                special keys in templates.
            depth: int, current recursion stack level, used to stop rerunning function when predefined limit
                (self._recursion_limit) has been reached.

        Returns:
            response: string, model response to provided prompt, generated text accordingly to the step.
        """
        prompt = self._get_template(step_type, input_content)
        response = openai.Completion.create(
            engine=config[step_type]['engine'],
            prompt=prompt,
            temperature=config[step_type]['temperature'],
            max_tokens=config[step_type]['max_tokens']
        )
        response = response['choices'][0]['text']

        # Two conditions to handle empty input and wrong hint/suggestion format. Reruns function.
        output_format = re.compile('1.*2.*3.*')
        if step_type in ["hint_generation", "suggestion_generation"] and output_format.match(response) is None:
            if depth < self._recursion_limit:
                warnings.warn(f"Failed to generate {step_type} correctly. Wrong format. Rerunning function.")
                response = self._send_to_openai(step_type, input_content, depth + 1)
        if len(response) == 0:
            if depth < self._recursion_limit:
                warnings.warn(f"Failed to generate {step_type} correctly. Empty string. Rerunning function.")
                response = self._send_to_openai(step_type, input_content, depth + 1)
        return response

    def _get_saving_path(self) -> str:
        """Creates path for saving purposes based on current datetime and original, input basename."""
        today_date = str(datetime.today()) \
            .replace("-", "") \
            .replace(" ", "_") \
            .replace(":", "").split(".")[0]
        file_basename = path.basename(self._test_data_filename).split(".")[0]
        saving_path = f"./data/{today_date}_{file_basename}.json"
        return saving_path

    @staticmethod
    def _process_output(output: str) -> list:
        """Splitting the text using regex to remove numbers - used for generated hints and suggestions.

        Args:
            output: string, raw text generated by LLM.

        Returns:
            separated_hints: list[string], list of hints or suggestions extracted from text.
        """
        pattern = re.split(r'\d+\.\s+', output)
        separated_hints = [part.replace("\\n", "") for part in pattern if part.strip()]
        # TODO: Add exception to replace all hints as one and two empty if format is different than expected.
        return separated_hints

    def generate_data(self):
        """Main function to run while preparing test dataset. Generates:
            - hints,
            - suggestions,
            - revised hints,
            - revised prompts.
        Texts, generated with OpenAI, are saved in the same structure as original test.json. The flow looks as follows:
        for every initial prompt some number of hints (3) is generated. For each hint model provides (3) suggestions
        and the 4th (unchanged) option is attached. For every suggestion combination (8-1 per hint) revised hints
        are produced. Lastly, for each hint combination (512) LLM creates the final, enhanced prompt that is supposed to
        be better than an initial prompt.
        """
        initial_prompt_ids = list(self._test_data['test'].keys())
        outputs = self._test_data['outputs']

        for initial_prompt_id in initial_prompt_ids:
            initial_prompt = self._test_data['test'][initial_prompt_id]['initial_prompt']

            # Save initial prompt value into 'outputs' structure.
            outputs[initial_prompt_id].update({'initial_prompt': initial_prompt})
            input_content = {
                "initial_prompt": initial_prompt,
                "generated_hint": "",
                "generated_suggestion": "",
                "revised_hints": ""
            }
            gen_hints = self._send_to_openai('hint_generation', input_content)
            listed_hints = self._process_output(gen_hints)
            outputs[initial_prompt_id].update({"hints": dict()})
            hints = outputs[initial_prompt_id]["hints"]

            for hint_id, hint_value in enumerate(listed_hints):
                # Save hint value into 'outputs' structure.
                hints[str(hint_id)].update({"value": hint_value})
                input_content.update({'generated_hint': hint_value})
                # Generate suggestions.
                gen_hint_suggestions = self._send_to_openai('suggestion_generation', input_content)
                listed_hint_suggestions = self._process_output(gen_hint_suggestions)
                listed_hint_suggestions.append('Do not specify (do not change initial hint)')
                hints[str(hint_id)].update({"suggestions": dict()})
                hint_suggestions = hints[str(hint_id)]["suggestions"]
                for suggestion_id in self._possible_hint_suggestions:
                    hint_suggestion = ' '.join([
                        listed_hint_suggestions[int(chosen_suggestion)] for chosen_suggestion in list(suggestion_id)]
                    )
                    # Save hint suggestion value into 'outputs' structure.
                    hint_suggestions[suggestion_id].update({"value": hint_suggestion})
                    input_content.update({'generated_suggestion': hint_suggestion})
                    if hint_suggestion == 'Do not specify (do not change initial hint)':
                        gen_hint_revision = hint_value
                    else:
                        gen_hint_revision = self._send_to_openai('hint_revision', input_content)
                    # Save revised hint value into 'outputs' structure.
                    hint_suggestions[suggestion_id].update({"revision": gen_hint_revision})

            self._test_data['outputs'][initial_prompt_id].update({'revisions': dict()})
            revisions = self._test_data['outputs'][initial_prompt_id]['revisions']
            # Generate prompt revisions.
            for combination in self._suggestions:
                revised_hints_ids = combination.split("-")
                revised_hints = list()
                for hint_id, hint_value in enumerate(listed_hints):
                    revised_hints.append(hints[str(hint_id)]["suggestions"][revised_hints_ids[hint_id]]["revision"])
                generated_hints = ' '.join(hint for hint in revised_hints)
                input_content.update({"revised_hints": generated_hints})
                gen_revision = self._send_to_openai('prompt_revision', input_content)
                # Save prompt revision value into 'outputs' structure.
                revisions[combination].update({'value': gen_revision})

        # Save configuration options used for generation in test dataset.
        self._test_data["config"] = config

        with open(self._saving_path, 'w', encoding='utf-8') as f:
            json.dump(self._test_data, f, indent=2)
