from datetime import datetime
import streamlit as st
import requests
import openai
import time
import re
import json

with open("./files/demo.json", "r") as f:
    demo_data = json.load(f)

with open("./files/config.json", "r") as f:
    config = json.load(f)

openai.api_type = config['api_config_azure']['api_type']
openai.api_version = config['api_config_azure']['api_version']
openai.api_base = config['api_config_azure']['api_base']
openai.api_key = config['api_config_azure']['api_key']

chatai_api_key = config['api_config_chatai']['api_key']
chatai_url = config['api_config_chatai']['url']
chatai_content_type = config['api_config_chatai']['content_type']


class MultiselectSuggestion:
    """Class to create repetitive, expanding elements with hint revision according to selected suggestions.
    Prints initial state (hint, multi-selection element) after initialization.

    Attributes:
        _expander: st.expander, multi-element container with initial hint content, multi-select element, button for
            hint revision and revised text content.
        _options: list, list of four suggestions for hint customization.
        _key: string, unique hint key, e.g., "handle_hint_0" for first hint.
        _hint_id: int, hint id.
        _previous_expanders: list[st.expander], list of all previous expanders, e.g., for hint_id == 2 previous
            expanders are 0 and 1. Used to perceive all hints printed.
        _multiselect_suggestions: st.multiselect, box for suggestion multi-selection.
    """
    def __init__(self, hint_id, previous_expanders):
        self._expander = st.expander(st.session_state["generated_hint_"+str(hint_id)], expanded=True)
        self._options = st.session_state["generated_suggestions_"+str(hint_id)]
        self._key = "handle_hint_"+str(hint_id)
        self._hint_id = hint_id
        self._previous_expanders = previous_expanders

        self._disable_multiselection = False
        self._disable_type_yourself_button = False
        if self._key + '_type_yourself_used' in st.session_state:
            self._disable_multiselection = True
            self._disable_type_yourself_button = True
        if self._key + '_multiselection_used' in st.session_state:
            self._disable_type_yourself_button = True

        self._multiselect_suggestions = self._expander.multiselect(
            label='Choose the option(s)',
            options=self._options,
            on_change=self.multiselect_suggestion_on_change,
            key=self._key,
            max_selections=3,
            disabled=self._disable_multiselection
        )

        if not self._disable_type_yourself_button:
            self._expander.button(
                label='Type custom suggestions yourself',
                key=self._key + "_type_custom_suggestion_button",
                on_click=self.type_suggestions_yourself,
                disabled=self._disable_type_yourself_button,
                use_container_width=True
            )

        if 'generated_revised_hint_'+str(self._hint_id) in st.session_state and \
                "revise_prompt" not in st.session_state and "revise_prompt_clicked" not in st.session_state:
            self._expander.write(st.session_state['generated_revised_hint_'+str(self._hint_id)])

    def get_expander(self):
        """Getter for MultiselectSuggestion expander attribute."""
        return self._expander

    def type_suggestions_yourself(self, disabled: bool = False):

        if self._key+'_type_yourself_used' not in st.session_state:
            st.session_state[self._key+'_type_yourself_used'] = True

        hint_0, hint_1, hint_2 = gen_hints_on_click()
        if self._hint_id == 0:
            self._expander = hint_0.get_expander()
        if self._hint_id == 1:
            self._expander = hint_1.get_expander()
        if self._hint_id == 2:
            self._expander = hint_2.get_expander()

        with self._expander.form(key=self._key+'_input_form'):
            st.text_input(
                label='Type your custom suggestions:',
                key=self._key+"_input_suggestions",
                placeholder='No custom suggestions has been written. Provide at least one suggestion.',
                disabled=disabled
            )
            st.form_submit_button(
                label='Revise hint with selected options',
                args=st.session_state[self._key + "_input_suggestions"],
                on_click=self.generate_hint_revision,
                disabled=disabled,
                use_container_width=True
            )
            st.session_state[f"hint_{self._hint_id}_constructor"] = True

    def multiselect_suggestion_on_change(self, disabled=False):
        """Prints button for hint revision generation. Keeps previous hints multi-selection actions printed."""
        if self._key+'_multiselection_used' not in st.session_state:
            st.session_state[self._key+'_multiselection_used'] = True
        hint_0, hint_1, hint_2 = gen_hints_on_click()

        if self._hint_id == 0:
            self._expander = hint_0.get_expander()
        if self._hint_id == 1:
            self._expander = hint_1.get_expander()
        if self._hint_id == 2:
            self._expander = hint_2.get_expander()

        if len(st.session_state[self._key]) > 0:
            if not disabled:
                self._expander.button(
                    label='Revise hint with selected options',
                    key=self._key + "_revision",
                    on_click=self.generate_hint_revision,
                    disabled=disabled,
                    use_container_width=True
                )
            st.session_state[f"hint_{self._hint_id}_constructor"] = True
            if 'suggestions_to_use_' + str(self._hint_id) not in st.session_state:
                st.session_state['suggestions_to_use_' + str(self._hint_id)] = \
                    st.session_state['handle_hint_' + str(self._hint_id)]
            else:
                st.session_state['suggestions_to_use_' + str(self._hint_id)] = \
                    st.session_state['handle_hint_' + str(self._hint_id)]

    def generate_hint_revision(self):
        """Prints revised hint inside expanding container."""
        if self._key + "_input_suggestions" in st.session_state:
            self.type_suggestions_yourself(disabled=True)
            st.session_state['suggestions_to_use_' + str(self._hint_id)] = \
                st.session_state[self._key + "_input_suggestions"]
        else:
            self.multiselect_suggestion_on_change(disabled=True)

        revision_conditions = [
            self._key + "_revision" in st.session_state and st.session_state[self._key + "_revision"],
            f"FormSubmitter:{self._key}_input_form-Revise hint with selected options" in st.session_state
        ]
        if any(revision_conditions):
            with self._expander:
                with st.spinner('Revising hint...'):
                    hint_suggestion = ' '.join([
                        suggestion for suggestion in st.session_state['suggestions_to_use_' + str(self._hint_id)]]
                    )
                    input_content = {
                        "initial_prompt": st.session_state.input_initial_prompt,
                        "generated_hint": st.session_state['generated_hint_'+str(self._hint_id)],
                        "generated_suggestion": hint_suggestion,
                        "revised_hints": ""
                    }
                    if input_content["generated_suggestion"] == 'Do not specify (do not change initial hint).':
                        gen_hint_revision = input_content["generated_hint"]
                    else:
                        if st.session_state["model_selection"] == "davinci":
                            gen_hint_revision = send_to_openai('hint_revision', input_content)
                        elif st.session_state["model_selection"] == "chatai":
                            gen_hint_revision = send_to_chatai('hint_revision', input_content)

                    if 'generated_revised_hint_'+str(self._hint_id) not in st.session_state:
                        st.session_state['generated_revised_hint_'+str(self._hint_id)] \
                            = gen_hint_revision
        self._expander.write(st.session_state['generated_revised_hint_'+str(self._hint_id)])
        st.session_state["hint_revision_" + str(self._hint_id)] = True


def get_session_results():
    session_results_to_download = {
        "model": st.session_state["model_selection"],
        "initial_prompt": st.session_state["input_initial_prompt"],
        "hint_0": {
            "initial": st.session_state["generated_hint_0"],
            "suggestions": st.session_state["suggestions_to_use_0"],
            "revised": st.session_state["generated_revised_hint_0"]
        },
        "hint_1": {
            "initial": st.session_state["generated_hint_1"],
            "suggestions": st.session_state["suggestions_to_use_1"],
            "revised": st.session_state["generated_revised_hint_1"]
        },
        "hint_2": {
            "initial": st.session_state["generated_hint_2"],
            "suggestions": st.session_state["suggestions_to_use_2"],
            "revised": st.session_state["generated_revised_hint_2"]
        },
        "revised_prompt": st.session_state["revised_prompt"],
        "answer": st.session_state["answer"]
    }
    json_session_results_to_download = json.dumps(session_results_to_download, indent=2)
    return json_session_results_to_download


def get_detailed_session_results():
    det_session_results_to_download = {
        "model": st.session_state["model_selection"],
        "initial_prompt": st.session_state["input_initial_prompt"],
        "hint_0": {
            "initial": st.session_state["generated_hint_0"],
            "suggestions": st.session_state["suggestions_to_use_0"],
            "revised": st.session_state["generated_revised_hint_0"]
        },
        "hint_1": {
            "initial": st.session_state["generated_hint_1"],
            "suggestions": st.session_state["suggestions_to_use_1"],
            "revised": st.session_state["generated_revised_hint_1"]
        },
        "hint_2": {
            "initial": st.session_state["generated_hint_2"],
            "suggestions": st.session_state["suggestions_to_use_2"],
            "revised": st.session_state["generated_revised_hint_2"]
        },
        "revised_prompt": st.session_state["revised_prompt"],
        "answer": st.session_state["answer"],
        "config": config["template_config"]
    }
    json_det_session_results_to_download = json.dumps(det_session_results_to_download, indent=2)
    return json_det_session_results_to_download


def generate_answer():
    """Generates final answer as a result of revised prompt served to LLM.

    Returns:
        -
    """
    revise_prompt(disabled=True)
    if 'answer' not in st.session_state:
        with st.spinner('Generating answer...'):
            if st.session_state["model_selection"] == "davinci":
                response = openai.Completion.create(
                    engine=config['template_config']['prompt_revision']['engine'],
                    prompt=st.session_state.revised_prompt,
                    temperature=config['template_config']['prompt_revision']['temperature'],
                    max_tokens=512
                )
                response = response['choices'][0]['text']
            elif st.session_state["model_selection"] == "chatai":
                headers = {"Content-type": chatai_content_type, "api-key": chatai_api_key}
                input_data = {
                    "messages": [
                        {"role": "system",
                         "content": "You are an AI Assistant that helps employees with their daily work."},
                        {"role": "user", "content": st.session_state.revised_prompt}
                    ],
                    "max_tokens": 512,
                    "presence_penalty": 1.5,
                    "frequency_penalty": 0.0,
                    "temperature": 0.5
                }
                full_response = requests.post(chatai_url, json=input_data, headers=headers)
                if full_response.status_code == 200:
                    response = full_response.json()['choices'][0]['message']['content']
                elif full_response.status_code == 429:
                    with st.spinner('Too many requests, please wait...'):
                        time.sleep(180)
                    full_response = requests.post(chatai_url, json=input_data, headers=headers)
                    response = full_response.json()['choices'][0]['message']['content']
            if 'answer' not in st.session_state:
                st.session_state.answer = response
    st.success('Done!')
    st.subheader('Answer:')
    st.write(st.session_state['answer'])
    st.write('---')

    session_results = get_session_results()
    detailed_session_results = get_detailed_session_results()
    file_name = st.session_state["input_initial_prompt"] \
        .replace(".", "") \
        .replace("?", "") \
        .replace(",", "") \
        .replace(" ", "_")
    file_name = file_name.lower()
    today_date = str(datetime.today()) \
        .replace("-", "") \
        .replace(" ", "_") \
        .replace(":", "").split(".")[0]

    left_column, middle_column, right_column = st.columns(3)
    with left_column:
        st.button("Clear session and try it again!",
                  on_click=clear_session,
                  key='clear_session',
                  disabled=False,
                  use_container_width=True,
                  type="primary"
                  )
    with middle_column:
        st.download_button(
            label="Download results as JSON",
            on_click=generate_answer,
            data=session_results,
            file_name=f'{today_date}_{file_name}.json',
            mime='text/json',
            use_container_width=True
        )
    with right_column:
        st.download_button(
            label="Download **detailed** results as JSON",
            on_click=generate_answer,
            data=detailed_session_results,
            file_name=f'{today_date}_detailed_{file_name}.json',
            mime='text/json',
            use_container_width=True
        )


def clear_session():
    """Delete all the items in Session state."""
    if st.session_state['clear_session']:
        for key in st.session_state.keys():
            del st.session_state[key]
        st.session_state.feature_selected = ':pencil: Try it'
        run_try_it(disabled=False)


def revise_prompt(disabled=False):
    """Revises initial prompt according to redesigned hints. Keeps all history printed on side. Works on button click.
    Defines button to generate the final answer.

    Args:
        disabled: disables final answer generation button after click.

    Returns:
        -
    """
    if "revise_prompt_clicked" not in st.session_state:
        st.session_state["revise_prompt_clicked"] = True
    hint_0, hint_1, hint_2 = gen_hints_on_click(disabled=True)
    if not disabled:
        with st.spinner('Revising initial prompt...'):
            revised_hints = [st.session_state['generated_revised_hint_0'],
                             st.session_state['generated_revised_hint_1'],
                             st.session_state['generated_revised_hint_2']]
            generated_hints = ' '.join(hint+"\n" for hint in revised_hints)
            input_content = {
                "initial_prompt": st.session_state.input_initial_prompt,
                "generated_hint": "",
                "generated_suggestion": "",
                "revised_hints": generated_hints
            }
            if st.session_state["model_selection"] == "davinci":
                gen_revision = send_to_openai('prompt_revision', input_content)
            elif st.session_state["model_selection"] == "chatai":
                gen_revision = send_to_chatai('prompt_revision', input_content)
            if 'revised_prompt' not in st.session_state:
                st.session_state.revised_prompt = gen_revision
    st.success('Done!')
    st.divider()
    st.subheader('Your new prompt is:')
    st.write(st.session_state['revised_prompt'])
    st.divider()
    for hint_id, hint in enumerate([hint_0, hint_1, hint_2]):
        hint.get_expander().write(st.session_state['generated_revised_hint_'+str(hint_id)])
    st.button("Use prompt",
              on_click=generate_answer,
              key='generate_answer',
              disabled=disabled,
              use_container_width=True
              )
    if not disabled:
        st.button("Clear session and try it again!",
                  on_click=clear_session,
                  key='clear_session',
                  disabled=disabled,
                  use_container_width=True,
                  type="primary"
                  )


def get_template(step_type: str, input_content: dict) -> str:
    """Returns appropriate template form config file, depending on step_type.

    Args:
        step_type: string, specifies what type of generation is performed.
        input_content: dict, texts used to replace keys in the template.

    Returns:
        template: string, template with filled information.
    """
    template = config["template_config"][step_type]['template']
    return template \
        .replace("[INITIAL PROMPT]", input_content['initial_prompt']) \
        .replace("[GENERATED HINT]", input_content['generated_hint']) \
        .replace("[GENERATED SUGGESTION]", input_content['generated_suggestion']) \
        .replace("[REVISED HINTS]", input_content['revised_hints'])


def process_output(output: str) -> list:
    """Splitting the text using regex to remove numbers - used for generated hints and suggestions.

    Args:
        output: string, raw text generated by LLM.

    Returns:
        separated_hints: list[string], list of hints or suggestions extracted from text.
    """
    pattern = re.split(r'\d+\.\s+', output)
    separated_hints = [part.replace("\n", " ") for part in pattern if part.strip()]
    return separated_hints


def send_to_openai(step_type: str, input_content: dict, depth: int = 0) -> str:
    """Sends input text with relevant template.

    Args:
        step_type: string, may be one of: "hint_generation", "suggestion generation", "hint revision" and
            "prompt revision", specifies what template should be used.
        input_content: dictionary, contains elements such as hints, suggestions etc. that are used to replace
            special keys in templates.
        depth: int, current recursion stack level, used to stop rerunning function when predefined limit
            (self._recursion_limit) has been reached.

    Returns:
        response: string, model response to provided prompt, generated text accordingly to the step.
    """
    recursion_limit = 3
    prompt = get_template(step_type, input_content)
    response = openai.Completion.create(
        engine=config["template_config"][step_type]['engine'],
        prompt=prompt,
        temperature=config["template_config"][step_type]['temperature'],
        max_tokens=config["template_config"][step_type]['max_tokens'],
        frequency_penalty=config["template_config"][step_type]['frequency_penalty'],
        presence_penalty=config["template_config"][step_type]['presence_penalty']
    )
    response = response['choices'][0]['text']

    # List of exceptions.
    exceptions = [
        re.search('3.', response) is None,
        re.search('2.', response) is None,
        re.search('2.\n3.', response) is not None,
        '?' not in response and step_type == "hint_generation",
        response[0] == "2",
        re.search('N/A', response) is not None
    ]

    if step_type in ["hint_generation", "suggestion_generation"]:
        if any(exceptions):
            if depth < recursion_limit:
                st.toast(f"Failed to generate {step_type} correctly. Wrong format. Rerunning generation. Please wait.")
                response = send_to_openai(step_type, input_content, depth + 1)
        else:
            response = "1. " + response
    if len(response) == 0:
        if depth < recursion_limit:
            st.toast(f"Failed to generate {step_type} correctly. Empty string. Rerunning generation. Please wait.")
            response = send_to_openai(step_type, input_content, depth + 1)
    return response


def send_to_chatai(step_type: str, input_content: dict) -> str:
    """
    TODO: Finish description.
    Args:
        step_type:
        input_content:

    Returns:

    """
    prompt = get_template(step_type, input_content)
    headers = {
        "Content-type": chatai_content_type,
        "api-key": chatai_api_key
    }
    input_data = {
        "messages": [
            {
                "role": "system",
                "content": config["template_config"][step_type]["system_message"]
            },
            {
                "role": "user",
                "content": prompt
            }
        ],
        "max_tokens": config["template_config"][step_type]['max_tokens'],
        "presence_penalty": config["template_config"][step_type]['presence_penalty'],
        "temperature": config["template_config"][step_type]['temperature'],
        "frequency_penalty": config["template_config"][step_type]['frequency_penalty']
    }
    response = requests.post(chatai_url, json=input_data, headers=headers)
    if response.status_code == 200:
        return response.json()['choices'][0]['message']['content']
    elif response.status_code == 429:
        with st.spinner('Too many requests, please wait...'):
            time.sleep(180)
        response = requests.post(chatai_url, json=input_data, headers=headers)
        return response.json()['choices'][0]['message']['content']
    else:
        st.toast('Request failed! Unknown error.')


def get_models_completion():
    input_content = {
        "initial_prompt": st.session_state.input_initial_prompt,
        "generated_hint": "",
        "generated_suggestion": "",
        "revised_hints": ""
    }
    # Generate hints.
    gen_hints = ""
    if st.session_state["model_selection"] == "davinci":
        gen_hints = send_to_openai('hint_generation', input_content)
    elif st.session_state["model_selection"] == "chatai":
        gen_hints = send_to_chatai('hint_generation', input_content)
    listed_hints = process_output(gen_hints)
    if 'generated_hint_0' not in st.session_state:
        st.session_state.generated_hint_0 = listed_hints[0]
    if 'generated_hint_1' not in st.session_state:
        st.session_state.generated_hint_1 = listed_hints[1]
    if 'generated_hint_2' not in st.session_state:
        st.session_state.generated_hint_2 = listed_hints[2]
    # Generate suggestions.
    for hint_id, hint_value in enumerate(listed_hints):
        input_content.update({'generated_hint': hint_value})
        gen_hint_suggestions = ""
        if st.session_state["model_selection"] == "davinci":
            gen_hint_suggestions = send_to_openai('suggestion_generation', input_content)
        elif st.session_state["model_selection"] == "chatai":
            gen_hint_suggestions = send_to_chatai('suggestion_generation', input_content)
        listed_hint_suggestions = process_output(gen_hint_suggestions)
        listed_hint_suggestions.append('Do not specify (do not change initial hint).')
        if 'generated_suggestions_' + str(hint_id) not in st.session_state:
            st.session_state['generated_suggestions_' + str(hint_id)] = listed_hint_suggestions


def gen_hints_on_click(disabled: bool = False):
    """Generates hints on button click in expanding containers.

    Args:
        disabled: boolean, turns off possibility to click initial prompt revision button, when it was used.

    Returns:
        hint_0: MultiselectSuggestion class object for hint no 0.
        hint_1: MultiselectSuggestion class object for hint no 1.
        hint_2: MultiselectSuggestion class object for hint no 2.
    """
    insert_initial_prompt(disabled=True)
    if st.session_state["FormSubmitter:input_form-Generate hints"]:
        with st.spinner('Generating hints...'):
            get_models_completion()
        st.success('Done!')

    if 'hint_revision_0' not in st.session_state:
        st.session_state.hint_revision_0 = False
    if 'hint_revision_1' not in st.session_state:
        st.session_state.hint_revision_1 = False
    if 'hint_revision_2' not in st.session_state:
        st.session_state.hint_revision_2 = False
    if 'hint_0_constructor' not in st.session_state:
        st.session_state.hint_0_constructor = False
    if 'hint_1_constructor' not in st.session_state:
        st.session_state.hint_1_constructor = False
    if 'handle_hint_2_revision' not in st.session_state:
        st.session_state.handle_hint_2_revision = False

    hint_0 = MultiselectSuggestion(hint_id=0, previous_expanders=[])
    hint_1 = MultiselectSuggestion(hint_id=1, previous_expanders=[hint_0.get_expander()])
    hint_2 = MultiselectSuggestion(hint_id=2, previous_expanders=[hint_0.get_expander(), hint_1.get_expander()])

    prompt_conditions = [
        st.session_state['handle_hint_2_revision'],
        "FormSubmitter:handle_hint_2_input_form-Revise hint with selected options" in st.session_state
    ]

    if any(prompt_conditions):
        if not disabled:
            st.button(
                "Revise initial prompt",
                on_click=revise_prompt,
                key='revise_prompt',
                disabled=disabled,
                use_container_width=True
            )

    if not disabled:
        st.button("Clear session and try it again!",
                  on_click=clear_session,
                  key='clear_session',
                  disabled=disabled,
                  use_container_width=True,
                  type="primary"
                  )

    return hint_0, hint_1, hint_2


def insert_initial_prompt(disabled=False):
    run_try_it(disabled=True)
    with st.form(key='input_form', clear_on_submit=False):
        st.text_input(
            label='Type initial prompt:',
            key="input_initial_prompt",
            placeholder='No prompt has been written. Provide your initial prompt.',
            disabled=disabled
        )
        st.form_submit_button(
            "Generate hints",
            args=st.session_state['input_initial_prompt'],
            on_click=gen_hints_on_click,
            disabled=disabled,
            use_container_width=True
        )

    if not disabled:
        st.button("Clear session and try it again!",
                  on_click=clear_session,
                  key='clear_session',
                  disabled=disabled,
                  use_container_width=True,
                  type="primary"
                  )


def run_try_it(disabled=False):
    """Main function to run after selecting "Demo" option in sidebar. Gets initial prompt from a User
    and creates button (hint generation) to initiate further steps.

    Returns:
        -
    """
    st.title(":pencil: Try it")
    st.divider()
    if "model_selection" not in st.session_state:
        st.session_state["model_selection"] = "chatai"

    left_col, right_col = st.columns(spec=[0.55, 0.35])
    with left_col:
        st.radio(
            "**Select AI model**",
            ["", "davinci", "chatai"],
            captions=["", "Model available through Azure OpenAI (davinci-001).", "Company internal GPT-4 model."],
            on_change=run_try_it,
            key="model_selection",
            horizontal=True,
            disabled=disabled
        )
    with right_col:
        st.button("Confirm choice",
                  on_click=insert_initial_prompt,
                  key='model_selection_confirmation',
                  disabled=disabled,
                  use_container_width=True
                  )
