import streamlit as st
import time
import json

with open("./files/demo.json", "r") as f:
    demo_data = json.load(f)


class MultiselectSuggestion:
    """Class to create repetitive, expanding elements with hint revision according to selected suggestions.
    Prints initial state (hint, multi-selection element) after initialization.

    Attributes:
        _expander: st.expander, multi-element container with initial hint content, multi-select element, button for
            hint revision and revised text content.
        _options: list, list of four suggestions for hint customization.
        _key: string, unique hint key, e.g., "handle_hint_0" for first hint.
        _hint_id: int, hint id.
        _previous_expanders: list[st.expander], list of all previous expanders, e.g., for hint_id == 2 previous
            expanders are 0 and 1. Used to perceive all hints printed.
        _multiselect_suggestions: st.multiselect, box for suggestion multi-selection.
    """
    def __init__(self, hint_id, previous_expanders):
        self._expander = st.expander(demo_data['hint_0'+str(hint_id)]['initial'], expanded=True)
        self._options = demo_data['hint_0'+str(hint_id)]['suggestions']
        self._key = "handle_hint_"+str(hint_id)
        self._hint_id = hint_id
        self._previous_expanders = previous_expanders

        self._disable_multiselection = False
        self._disable_type_yourself_button = False
        if self._key + '_type_yourself_used' in st.session_state:
            self._disable_multiselection = True
            self._disable_type_yourself_button = True
        if self._key + '_multiselection_used' in st.session_state:
            self._disable_type_yourself_button = True

        self._multiselect_suggestions = self._expander.multiselect(
            label='Choose the option(s)',
            options=self._options,
            on_change=self.multiselect_suggestion_on_change,
            key=self._key,
            max_selections=4,
            disabled=self._disable_multiselection
        )
        self._expander.button(
            label='Type custom suggestions yourself',
            key=self._key + "_type_custom_suggestion_button",
            on_click=self.type_suggestions_yourself,
            disabled=self._disable_type_yourself_button
        )

    def get_expander(self):
        """Getter for MultiselectSuggestion expander attribute."""
        return self._expander

    def type_suggestions_yourself(self, disabled: bool = False):

        if self._key+'_type_yourself_used' not in st.session_state:
            st.session_state[self._key+'_type_yourself_used'] = True

        hint_0, hint_1, hint_2 = gen_hints_on_click()
        for i, previous_expander in enumerate(self._previous_expanders):
            st.session_state["handle_hint_" + str(i) + "_revision"] = True
            previous_expander.button(
                label='Revise hint with selected options',
                key='hold_hint_revision_button_' + str(i),
                disabled=True
            )
            previous_expander.write(demo_data['hint_0' + str(i)]['revised'])
        if self._hint_id == 0:
            self._expander = hint_0.get_expander()

        with self._expander.form(key=self._key+'_input_form'):
            st.text_input(
                label='Type your custom suggestions:',
                key=self._key+"_input_suggestions",
                placeholder='No custom suggestions has been written. Provide at least one suggestion.',
                disabled=disabled
            )
            st.form_submit_button(
                label='Revise hint with selected options',
                args=st.session_state[self._key + "_input_suggestions"],
                on_click=self.generate_hint_revision,
                disabled=disabled
            )
            st.session_state[f"hint_{self._hint_id}_constructor"] = True

    def multiselect_suggestion_on_change(self, disabled=False):
        """Prints button for hint revision generation. Keeps previous hints multi-selection actions printed."""

        if self._key+'_multiselection_used' not in st.session_state:
            st.session_state[self._key+'_multiselection_used'] = True

        hint_0, hint_1, hint_2 = gen_hints_on_click()
        for i, previous_expander in enumerate(self._previous_expanders):
            st.session_state["handle_hint_"+str(i)+"_revision"] = True
            previous_expander.button(
                label='Revise hint with selected options',
                key='hold_hint_revision_button_'+str(i),
                disabled=True
            )
            previous_expander.write(demo_data['hint_0'+str(i)]['revised'])
        if len(st.session_state[self._key]) > 0:
            if self._hint_id == 0:
                self._expander = hint_0.get_expander()
            self._expander.button(
                label='Revise hint with selected options',
                key=self._key + "_revision",
                on_click=self.generate_hint_revision,
                disabled=disabled
            )
            st.session_state[f"hint_{self._hint_id}_constructor"] = True

    def generate_hint_revision(self):
        """Prints revised hint inside expanding container."""
        if self._key + "_input_suggestions" in st.session_state:
            self.type_suggestions_yourself(disabled=True)
        else:
            self.multiselect_suggestion_on_change(disabled=True)
        self._expander.write(demo_data['hint_0'+str(self._hint_id)]['revised'])
        st.session_state["hint_revision_" + str(self._hint_id)] = True


def generate_answer():
    """Generates final answer as a result of revised prompt served to LLM.

    Returns:
        -
    """
    revise_prompt(disabled=True)
    with st.spinner('Generating answer...'):
        time.sleep(1)
    st.success('Done!')
    st.subheader('Answer:')
    for t in [0, 1, 2]:
        st.write(demo_data['output']['text'][t])
        try:
            st.code(demo_data['output']['code'][t], language='python')
        except IndexError:
            continue
    st.write('---')


def revise_prompt(disabled=False):
    """Revises initial prompt according to redesigned hints. Keeps all history printed on side. Works on button click.
    Defines button to generate the final answer.

    Args:
        disabled: disables final answer generation button after click.

    Returns:
        -
    """
    hint_0, hint_1, hint_2 = gen_hints_on_click(disabled=True)
    if not disabled:
        with st.spinner('Revising initial prompt...'):
            time.sleep(1)
    st.success('Done!')
    st.divider()
    st.subheader('Your new prompt is:')
    st.write(demo_data['revised_prompt'])
    st.divider()
    for hint_id, hint in enumerate([hint_0, hint_1, hint_2]):
        hint.get_expander().write(demo_data['hint_0'+str(hint_id)]['revised'])
    st.button("Use prompt",
              on_click=generate_answer,
              key='generate_answer',
              disabled=disabled
              )


def gen_hints_on_click(disabled=False):
    """Generates hints on button click in expanding containers.

    Args:
        disabled: turns off possibility to click initial prompt revision button, when it was used.

    Returns:
        hint_0: MultiselectSuggestion class object for hint no 0.
        hint_1: MultiselectSuggestion class object for hint no 1.
        hint_2: MultiselectSuggestion class object for hint no 2.
    """
    run_demo(disabled=True)
    if st.session_state.generate_hints:
        with st.spinner('Generating hints...'):
            time.sleep(1)
        st.success('Done!')

    if 'hint_revision_0' not in st.session_state:
        st.session_state.hint_revision_0 = False
    if 'hint_revision_1' not in st.session_state:
        st.session_state.hint_revision_1 = False
    if 'hint_revision_2' not in st.session_state:
        st.session_state.hint_revision_2 = False
    if 'hint_0_constructor' not in st.session_state:
        st.session_state.hint_0_constructor = False
    if 'hint_1_constructor' not in st.session_state:
        st.session_state.hint_1_constructor = False
    if 'handle_hint_2_revision' not in st.session_state:
        st.session_state.handle_hint_2_revision = False

    hint_0 = MultiselectSuggestion(hint_id=0, previous_expanders=[])
    hint_1 = MultiselectSuggestion(hint_id=1, previous_expanders=[hint_0.get_expander()])
    hint_2 = MultiselectSuggestion(hint_id=2, previous_expanders=[hint_0.get_expander(), hint_1.get_expander()])

    prompt_conditions = [
        st.session_state['handle_hint_2_revision'],
        "FormSubmitter:handle_hint_2_input_form-Revise hint with selected options" in st.session_state
    ]

    if any(prompt_conditions):
        st.button(
            "Revise initial prompt",
            on_click=revise_prompt,
            key='revise_prompt',
            disabled=disabled
        )

    return hint_0, hint_1, hint_2


def run_demo(disabled=False):
    """Main function to run after selecting "Demo" option in sidebar. Gets initial prompt from a User
    and creates button (hint generation) to initiate further steps.

    Returns:
        -
    """
    st.title(":computer: Demo")
    st.divider()
    st.write(demo_data['disclaimer'])
    st.write(demo_data['description'])
    st.write(demo_data['disclaimer_suggestions'])
    st.divider()
    st.text_area(
        label='Type initial prompt:',
        placeholder=demo_data['initial_prompt'],
        disabled=True
    )
    st.button(
        "Generate hints",
        key='generate_hints',
        on_click=gen_hints_on_click,
        disabled=disabled
    )
