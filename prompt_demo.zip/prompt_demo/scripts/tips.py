import streamlit as st
import json

with open("./files/demo.json", "r") as f:
    demo_data = json.load(f)


def show_tips():
    """Shows prompt engineering tips while selected.

    Returns:
        -
    """
    st.title(":heavy_check_mark: General Tips for Designing Prompts")
    st.write('---')
    st.write('Here are some tips to keep in mind while you are designing your prompts:')
    st.markdown("### Start Simple")
    st.write(demo_data['tips_01'])
    st.markdown("### The Instruction")
    st.write(demo_data['tips_02'])
    st.code('### Instruction ###\n\n Translate the text below to Spanish: \n\n Text: "hello!"')
    st.write('Output:')
    st.code('¡Hola!')

    tips = '<p style="color:Red; font-size: 14px;">For visual purposes ' \
           'text has been copied from https://www.promptingguide.ai/introduction/tips</p>' # style="font-family:Noto CJK;
    st.markdown(tips, unsafe_allow_html=True)
